/* Copyright (c) 1994 Sun Wu, Udi Manber, Burra Gopal.  All Rights Reserved. */
#define NOSUCHFILE -3
#define OPENFAILED -2
#define STATFAILED -1
#define ISASCIIFILE 0
#define ISDIRECTORY 1
#define ISBLOCKFILE 2
#define ISSOCKET 3
#define ISBINARYFILE 4
