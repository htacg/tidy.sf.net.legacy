/* Generated automatically from paths.h.in by configure. */
#ifndef _PATHS_H_
#define _PATHS_H_

#ifndef CMD_PERL
#define CMD_PERL	"/usr/local/perl"
#endif

#ifndef CMD_GZIP
#define CMD_GZIP	"/usr/local/gzip"
#endif

#ifndef CMD_GUNZIP
#define CMD_GUNZIP	"/usr/local/gunzip"
#endif

#ifndef CMD_UNZIP
#define CMD_UNZIP	"/usr/local/unzip"
#endif

#ifndef CMD_UNCOMPRESS
#define CMD_UNCOMPRESS	"/usr/ucb/uncompress"
#endif

#endif
